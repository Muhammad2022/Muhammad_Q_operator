import UIKit
let Num1 = 526
let Num2 = 40
var add = Num1 + Num2
var sub = Num1 - Num2
var mult = Num1 * Num2
var div = Num1 / Num2
print("\(Num1) + \(Num2) = \(add)")
print("\(Num1) - \(Num2) = \(sub)")
print("\(Num1) * \(Num2) = \(mult)")
print("\(Num1) / \(Num2) = \(div)")
